from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from rich.color import ANSI_COLOR_NAMES, Color

if TYPE_CHECKING:
    from IPython import get_ipython  # only available in IPython/Jupyter


### ANCHOR: string modifier
def text_fill_center(input_text="example", fill="-", length=60):
    """Create a line with centered text."""
    text = f"{input_text}"
    return text.center(length, fill)


def text_fill_left(input_text="example", margin=15, fill_left="-", fill_right=" ", length=60):
    """Create a line with left-aligned text."""
    text = f"{(fill_left * margin)}{input_text}"
    return text.ljust(length, fill_right)


def text_fill_box(
    input_text: str = "", fill: str = " ", sp: str = "\u01c1", length: int = 60
) -> str:
    """
    Return a string centered in a box with side delimiters.

    Example:
        ```python
        text_fill_box("hello", fill="-", sp="|", length=20)
        '|-------hello-------|'
        ```

    Notes:
        - To input unicode characters, use the unicode escape sequence (e.g., "\u01c1" for a specific character). See [unicode-table]( https://symbl.cc/en/unicode-table) for more details.
            - ║ (Double vertical bar, `u2551`)
            - ‖ (Double vertical line, `u2016`)
            - ǁ (Latin letter lateral click, `u01C1`)
    """
    if len(sp) * 2 >= length:
        raise ValueError("Length must be greater than twice the side padding length")

    inner_width = length - 2 * len(sp)
    centered = input_text.center(inner_width, fill)
    return f"{sp}{centered}{sp}"


def text_repeat(input_str: str, length: int) -> str:
    """Repeat the input string to a specified length."""
    text = (input_str * ((length // len(input_str)) + 1))[:length]
    return text


#####ANCHOR: Make colored text
def text_color(text: str, color: str = "blue") -> str:
    """Return ANSI-colored text that works in terminal or Jupyter.

    Args:
        text (str): The input text.
        color (str, optional): Color name. Defaults to "blue". Supported string values include:
            - Color names: "black", "red", "green",...See [list here](https://github.com/Textualize/rich/blob/master/rich/color.py#L49)
            - Color ANSI codes: "#ff0000",... See codes [here](https://hexdocs.pm/color_palette/ansi_color_codes.html).
            - RGB codes: "rgb(255,0,0)",... See codes [here](https://en.wikipedia.org/wiki/ANSI_escape_code#8-bit).
    Notes
    - Based on [rich](https://github.com/Textualize/rich/blob/master/rich/color.py)'s color scheme.
    """
    if not _detect_console_env():
        text = text  # return plain text when writing to non-console (e.g., file)

    ### Make color text
    try:
        code = Color.parse(color).get_ansi_codes()
        if code is not None:
            code = code[0]
        else:
            raise Exception
    except Exception:
        print(f"WARNING: Color '{color}' not recognized — using white.")
        code = str(ANSI_COLOR_NAMES.get("white", 37))

    text = f"\033[{code}m{text}\033[0m"
    return text


def _detect_console_env() -> bool:
    """Detect if running in a console/jupyter environment."""
    result = False
    # Detect if running in IPython/Jupyter
    try:
        shell = get_ipython().__class__.__name__
        in_notebook = shell in ("ZMQInteractiveShell", "Shell")  # ZMQ = Jupyter
    except NameError:
        in_notebook = None

    # Only skip color if really non-terminal and not notebook
    if in_notebook is not None and sys.stdout.isatty():
        result = True
    return result


def _index2color(index: int) -> str:
    """Map an integer index to a color name."""
    color_map = {
        0: "blue",
        1: "green",
        2: "yellow",
        3: "magenta",
        4: "cyan",
        5: "red",
    }
    ### Add more colors from ANSI_COLOR_NAMES
    for idx, key in enumerate(ANSI_COLOR_NAMES.keys()):
        if key not in color_map.values():
            color_map[idx + 6] = key
    return color_map[int(index)]


#####ANCHOR: retired code


# def text_color_oldretired(text: str, color: str = "blue") -> str:
#     """ANSI escape codes for color the text."""
#     ### Make color text with \033[<code>m
#     ansi_code = {
#         "red": "91",
#         "green": "92",
#         "yellow": "93",
#         "blue": "94",
#         "magenta": "95",
#         "cyan": "96",
#         "white": "97",
#     }
#     if color not in ansi_code:
#         print(f"WARNING: Color '{color}' not recognized — using white.")
#         color = "white"

#     text = "\033[" + ansi_code[color] + "m" + text + "\033[0m"
#     return text
