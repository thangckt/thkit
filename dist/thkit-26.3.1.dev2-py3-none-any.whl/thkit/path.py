import logging
import shutil
from pathlib import Path


#####ANCHOR Make dirs
def make_dir(path: str | Path, backup: bool = True):
    """Create a directory with a backup option."""
    ### Create a backup path with a counter suffix
    if Path(path).is_dir() and backup:
        counter = 0
        while True:
            bk_path = Path(path).with_name(f"{Path(path).name}_bk{counter:03d}")
            if not bk_path.exists():
                shutil.move(str(path), str(bk_path))
                break
            counter += 1
    ### Create the new directory
    Path(path).mkdir(parents=True, exist_ok=True)
    return


def make_dir_ask_backup(dir_path: str, logger: logging.Logger | None = None):
    """Make a directory and ask for backup if the directory already exists."""
    prompt_text = (
        f"The directory '{dir_path}' already exists. \nSelect an action: [yes/no/backup]?\n"
        "  * Yes: overwrite the existing directory and continue/update unfinished tasks.\n"
        "  * No: stop and exit process.\n"
        "  * Backup: backup the existing directory and create a new directory for fresh tasks."
    )
    if Path(dir_path).is_dir():
        if logger is not None:
            logger.warning(prompt_text)
        else:
            print(prompt_text)

        ans = ask_yesnoback("\tInput your choice")
        if ans == "yes":
            print("\tOverwrite the existing directory")
            make_dir(dir_path, backup=False)
        elif ans == "backup":
            print("\tBackup the existing directory")
            make_dir(dir_path, backup=True)
        elif ans == "no":
            print("\tStop and exit")
            return
    else:
        make_dir(dir_path, backup=False)


def ask_yesnoback(prompt: str) -> str:
    """Ask user for a yes/no/backup response."""
    while True:
        answer = input(f"{prompt} [y/n/b]: ").strip().lower()
        if answer in ["yes", "y"]:
            return "yes"
        elif answer in ["no", "n"]:
            return "no"
        elif answer in ["backup", "b"]:
            return "backup"
        else:
            print("Please answer with 'yes/y', 'no/n', or 'backup/b'.")


def ask_yesno(prompt: str) -> str:
    """Ask user a yes/no question and return the normalized choice."""
    while True:
        answer = input(f"{prompt} [y/n]: ").strip().lower()
        if answer in ["yes", "y"]:
            return "yes"
        elif answer in ["no", "n"]:
            return "no"
        else:
            print("Please answer with 'yes/y' or 'no/n'.")


#####ANCHOR Collect files
def list_paths(
    paths: str | list[str],
    patterns: list[str],
    recursive=True,
) -> list[str]:
    """List all files/folders in given directories and their subdirectories that match the given patterns.

    Args:
        paths : str | list[str]
            One or more root directories to search.
        patterns : list[str]
            Glob patterns to match (e.g. "*.txt", "data*", "*/", "**/*.py").
        recursive : bool, default=True
            If True, search recursively using rglob().
            If False, search only the top-level directory using glob().

    Returns:
        list[str]: Sorted list of matching paths (POSIX style).

    Example:
    --------
    ```python
    folders = ["path1", "path2", "path3"]
    patterns = ["*.ext1", "*.ext2", "something*.ext3", "*folder/"]
    files = list_files_in_dirs(folders, patterns)
    ```

    Note:
    - glob() does not list hidden files by default. To include hidden files, use glob(".*", recursive=True).
    - When use recursive=True, must include `**` in the pattern to search subdirectories.
        - glob("*", recursive=True) will search all FILES & FOLDERS in the CURRENT directory.
        - glob("*/", recursive=True) will search all FOLDERS in the current CURRENT directory.
        - glob("**", recursive=True) will search all FILES & FOLDERS in the CURRENT & SUB subdirectories.
        - glob("**/", recursive=True) will search all FOLDERS in the current CURRENT & SUB subdirectories.
        - "**/*" is equivalent to "**".
        - "**/*/" is equivalent to "**/".
    - IMPORTANT: "**/**" will replicate the behavior of "**", then give unexpected results.

    Revised:
        - Use `Path.rglob()` is better than `"**"` strings
        - Hidden files are NOT matched unless explicitly included in a pattern (e.g. ".*").
        - When `recursive=True`, patterns are interpreted relative to each root path. You usually do NOT need to manually add "**".
        - Trailing "/" in patterns may be used to indicate directories.
    """
    root_paths = [paths] if not isinstance(paths, list) else paths

    results = []
    for p in root_paths:
        root = Path(p)
        if not root.exists():
            continue

        for pattern in patterns:
            if recursive:
                results.extend(root.rglob(pattern))
            else:
                results.extend(root.glob(pattern))

    return sorted(p.as_posix() for p in results)


def collect_files(
    paths: list[str | Path] | str,
    patterns: list[str],
    recursive: bool = True,
) -> list[str]:
    """Collect files from a list of paths (files/folders). Will search files in folders and their subdirectories.
    - Files are added directly.
    - Directories are searched recursively using the given patterns.
    - Glob patterns in `paths` are expanded as-is.

    Args:
        paths : list[str] | str
            The list of paths to collect files from.
        patterns : list[str]
            The list of patterns to apply to the files. Each filter can be a file extension or a pattern.
        recursive : bool, optional
            Whether to search directories recursively. Defaults to True.

    Returns:
    list[str]: Sorted list of matching file paths (POSIX style).
    """
    input_paths = [paths] if not isinstance(paths, list) else paths

    results = []

    ### Detemine paths: dirs, files, and patterns
    for p in input_paths:
        path = Path(p)

        if path.is_file():
            results.append(path)
        elif path.is_dir():  # Search files in directory recursively
            for match in list_paths(path, patterns, recursive):
                results.append(Path(match))
        else:  # Treat as glob pattern (e.g. "*.txt", "data/**/*.csv")
            for match in Path().glob(p):
                if match.is_file():
                    results.append(match)

    return sorted(p.as_posix() for p in set(results))


##### ANCHOR: change path names
def change_pathname(
    paths: list[str], old_string: str, new_string: str, replace: bool = False
) -> None:
    """Change path names.

    Args:
        paths (list[str]): paths to the files/dirs
        old_string (str): old string in path name
        new_string (str): new string in path name
        replace (bool, optional): replace the old path_name if the new one exists. Defaults to False.
    """
    ### Classify dirs and files
    paths = [p for p in paths if old_string in p]
    files = [p for p in paths if Path(p).is_file()]
    dirs = [p for p in paths if Path(p).is_dir()]
    print(f"There are {len(files)} files and {len(dirs)} directories, need to change.")

    ### Change the path names
    changed_count = 0
    for f in files:
        new_name = f.replace(old_string, new_string)
        if Path(new_name).exists() and not replace:
            print(f'WARNING: "{new_name}" already exists, skipping it.')
        else:
            Path(f).rename(new_name)
            changed_count += 1

    for d in dirs:
        new_name = d.replace(old_string, new_string)
        if Path(new_name).exists() and not replace:
            print(f'WARNING: "{new_name}" already exists, skipping it.')
        else:
            Path(d).rename(new_name)
            changed_count += 1

    print(f"Changed {changed_count} of {len(paths)} paths.")
    return


def remove_files(files: list[str]) -> None:
    """Remove files from a given list of file paths.

    Args:
        files (list[str]): list of file paths
    """
    _ = [Path(f).unlink() for f in files]
    return


def remove_dirs(dirs: list[str]) -> None:
    """Remove a list of directories.

    Args:
        dirs (list[str]): list of directories to remove.
    """
    dirs = [dirs] if not isinstance(dirs, list) else dirs
    _ = [shutil.rmtree(d) for d in dirs]
    return


def remove_files_in_paths(files: list, paths: list) -> None:
    """Remove files in the `files` list in the `paths` list."""
    _ = [Path(f"{p}/{f}").unlink() for p in paths for f in files if Path(f"{p}/{f}").exists()]
    return


def remove_dirs_in_paths(dirs: list, paths: list) -> None:
    """Remove directories in the `dirs` list in the `paths` list."""
    _ = [shutil.rmtree(f"{p}/{d}") for p in paths for d in dirs if Path(f"{p}/{d}").exists()]
    return


def copy_file(src_path: str, dest_path: str):
    """Copy a file/folder from the `source path` to the `destination path`. It will create the destination directory if it does not exist."""
    Path(dest_path).parent.mkdir(parents=True, exist_ok=True)
    new_path = shutil.copy2(src_path, dest_path)
    return new_path


def move_file(src_path: str, dest_path: str):
    """Move a file/folder from the source path to the destination path."""
    Path(dest_path).parent.mkdir(parents=True, exist_ok=True)
    new_path = shutil.move(src_path, dest_path)
    return new_path


def filter_dirs(
    dirs: list[str],
    has_files: list[str] | None = None,
    no_files: list[str] | None = None,
) -> list[str]:
    """Return directories containing `has_files` and none of `no_files`.

    Args:
        dirs: List of directory paths to scan.
        has_files: Files that must exist in the directory. Defaults to [].
        no_files: Files that must not exist in the directory. Defaults to [].

    Returns:
        List of directory paths meeting the conditions.
    """
    if has_files is not None:
        dirs = [d for d in dirs if all(Path(f"{d}/{f}").exists() for f in has_files)]
    if no_files is not None:
        dirs = [d for d in dirs if all(not Path(f"{d}/{f}").exists() for f in no_files)]
    return dirs
